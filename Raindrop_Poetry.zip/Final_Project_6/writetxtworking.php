<?php
if(!empty($_POST['data'])){
$data = $_POST['data'];
$fname = "hi.txt";//generates random name
$file = fopen("upload/" .$fname, 'a');//creates new file
fwrite($file, $data);
fclose($file);
}
?>