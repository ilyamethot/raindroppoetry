<?php
if(!empty($_POST['data'])){
$data = $_POST['data'];
$fname = "/home/ilyameme/public_html/raindrops/test.txt";//generates random name
$file = fopen($fname, 'a');//creates new file
fwrite($file, ',' . $data);
fclose($file);
}
?>